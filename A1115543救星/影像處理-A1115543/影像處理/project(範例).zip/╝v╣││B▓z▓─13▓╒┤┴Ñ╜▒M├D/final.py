import cv2
import numpy as np
import argparse
from PIL import Image

cap = cv2.VideoCapture('sports.mp4')

imgName=1

# 初始化平均影像
ret, frame = cap.read()
avg = cv2.blur(frame, (4, 4))
avg_float = np.float32(avg)

ap = argparse.ArgumentParser()

ap.add_argument("-a", "--method", type=str, default="telea",
	choices=["telea", "ns"],
	help="inpainting algorithm to use")
ap.add_argument("-r", "--radius", type=int, default=4,
	help="inpainting radius")
args = vars(ap.parse_args())

while(cap.isOpened()):
  # 讀取一幅影格
    ret, frame = cap.read()

  # 若讀取至影片結尾，則跳出
    if ret == False:
        print("exiting")
        break

  # 模糊處理
    blur = cv2.blur(frame, (4, 4))

  # 計算目前影格與平均影像的差異值
    diff = cv2.absdiff(avg, blur)

  # 將圖片轉為灰階
    gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)

  # 篩選出變動程度大於門檻值的區域
    ret, thresh = cv2.threshold(gray, 25, 255, cv2.THRESH_BINARY)

  # 使用型態轉換函數去除雜訊
    kernel = np.ones((1, 1), np.uint8)
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)

    #inpaint的部分
    flags = cv2.INPAINT_NS
    output = cv2.inpaint(frame, thresh.copy(), args["radius"], flags=flags)

    img1=np.array(thresh)
    img2=np.array(output)

    rows=img1.shape[0]
    cols=img1.shape[1]

    for i in range(rows):
        for j in range(cols):
              if (img1[i,j]!=0):#白色
                  if(i>0 and j>0 and i<rows-1 and j<cols-1):
                    #大小為9(0~8)的陣列
                    ans=[0]*9
                    ans2=[]
                    cnt=0
                    for s in range(i-1,i+2):
                      for t in range(j-1,j+2):
                        arr=img2[s,t]
                        ans[cnt]=(arr[0]+arr[1]+arr[2])/3
                        cnt=cnt+1

                    for num in ans: 
                        ans2.append(num) # add the calculation
                  
                    sorted(ans2)

                    img2[i,j]=ans2[4]

    output = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    cv2.imshow('frame', output) #顯示結果
    
    cv2.imwrite('./result/%d.jpg'%imgName,output)
    #存成圖片並放到result資料夾裡
    
    imgName=imgName+1

    if cv2.waitKey(1) == ord('q'):
      break

  # 更新平均影像
    cv2.accumulateWeighted(blur, avg_float, 0.01)
    avg = cv2.convertScaleAbs(avg_float)

cap.release()

#合併回影片
img = cv2.imread('./result/1.jpg')
imageInfo=img.shape
size=(imageInfo[1],imageInfo[0])

videoWrite=cv2.VideoWriter('road.mp4',-1,10,size)

for i in range (1,imgName):
        if(i%3==0):
            img=cv2.imread('./result/%d.jpg'%i)
            videoWrite.write(img)

cv2.destroyAllWindows()